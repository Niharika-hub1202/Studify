import streamlit as st
from google import genai
from google.genai import types

st.set_page_config(
    page_title="Studify",  
    page_icon= "https://play-lh.googleusercontent.com/9EnjUcV7kGHnLzI2sTF00u2j_ZT3nYsKJilwfkfGxWlBnk5dy6LUiifUGYVQZhx9dEM"
)

gemini_api=st.secrets['GEMINI_API_KEY']

st.title("Studify - Your AI Study Buddy")
st.write("Explain topics, summarize notes, and create quizzes or flashcards.")

# --- Application Layout ---
with st.sidebar:
    st.header("Settings")
    st.write("Adjust your preferences below:")
    model_name = st.selectbox(
        "Select Model",
        options=["gemini-2.5-flash"]
    )
    st.subheader("The Studify is an intelligent AI-Powered educational tool designed to help students learn more effectively and independently. By leveraging advanced AI models, this assistant can simplify complex topics, summarize study materials, and generate interactive quizzes or flashcards — all on demand.")
    

def get_response(prompt):
    client = genai.Client(api_key=gemini_api)

    response = client.models.generate_content(
        model="gemini-2.5-flash", contents=prompt, 
        config=types.GenerateContentConfig(
             thinking_config=types.ThinkingConfig(thinking_budget=0), # Disables thinking
        temperature=0.1
    )
    )     
    return response.text


def clean_option(line):
    return line.split(')', 1)[-1].strip()


def parse_questions(response_text):
    questions = []
    blocks = response_text.strip().split("\n\n")
    for block in blocks:
        lines = block.strip().split("\n")
        if len(lines) >= 6:
            q_text = lines[0].split('.', 1)[1].strip()
           
            options = {
                'a': clean_option(lines[1]),
                'b': clean_option(lines[2]),
                'c': clean_option(lines[3]),
                'd': clean_option(lines[4]),
            }
            answer_line = lines[5]
            correct_option = answer_line.split('=')[-1].strip()
            questions.append({
                'question': q_text,
                'options': options,
                'answer': correct_option
            })
    return questions

tab1, tab2,tab3,tab4 = st.tabs(["📚 Explain", "📝 Summerize", "💡Quiz", "🗃️ Flashcards"])

with tab1:
    st.markdown('''  
                    **Explain**
            ''')
    st.write(''' What do you want explained? ''')   
    prompt=st.text_input("Enter your topic or question here")
    level=st.selectbox("Level of detail", options=["Basic", "Intermediate", "Advanced"])
    style=st.selectbox("Preferred style", options=["Concise", "Detailed", "With Examples"])
    if st.button("Explain", use_container_width=True):
        response = get_response(f"Explain the topic '{prompt}' in a {level} manner, using a {style} style.")
        st.write(response)


with tab2:
     st.markdown('''  
                    **Summerize**
            ''')
     st.markdown(''' - You can either paste your notes/text or upload a file (txt format) for summarization. ''')
     prompt=st.text_area("Paste your notes/text or upload file")
     file_input = st.file_uploader("Upload a file", type=["txt"])
     length=st.selectbox("Length of summary", options=["Short", "Medium", "Long"])

     if st.button("Summerize", use_container_width=True):
         content = file_input.read().decode("utf-8") if file_input else prompt
         summary_prompt = f"Summarize the following text in {length} manner, capturing the key points and concepts in a concise manner.\n\nText: {content}"
         response = get_response(summary_prompt)
         st.write(response)



with tab3:
        st.markdown('''  
                        **Quiz**
                ''')
        quiz_text=st.text_area("Topic or source text for quiz")
        num_questions=st.selectbox("Number of questions", [3, 5,10])
        type_of_questions=st.selectbox("Type of questions", ["Multiple Choice", "Multi Select"])
        if st.button("Generate Quiz", use_container_width=True):
            content = file_input.read().decode("utf-8") if file_input else prompt

            res_format = """ Here are 3 multiple-choice questions based on the provided text:

                1. What is Anthony's favorite dish?
                a) Chicken
                b) Pasta
                c) Fish
                d) Pizza
                Answer=c

                2. What does Anthony like to do?
                a) Read books
                b) Watch TV
                c) Play sports
                d) Cook
                Answer=b
            """
            quiz_prompt = f"From the following text, create {num_questions} {type_of_questions} questions with answers.quiz question format eg- {res_format}.   Text: {quiz_text}"
            response = get_response(quiz_prompt)
            print(response)
            # st.write(response)
            questions = parse_questions(response)
            for idx, q in enumerate(questions):
                st.write(f"**Q{idx+1}: {q['question']}**")
                for opt_key, opt_val in q['options'].items():
                    st.write(f"- {opt_key}. {opt_val}")
                with st.expander("Show Answer"):
                    st.write(f"*Answer: {q['answer']}*")
                st.write("---")


with tab4:
        st.markdown('''  
                        **Flashcards**
                ''')
        flashcard_text=st.text_area("Topic or source text for flashcards")
        num_flashcards=st.selectbox("Number of flashcards", [1,3,5,10])
        if st.button("Generate Flashcards", use_container_width=True):
            flashcard_prompt = f"From the following text, create {num_flashcards} flashcards, with topic on one side and defination on other side.\n\nText: {flashcard_text}"
            response = get_response(flashcard_prompt)

            st.markdown("""
            <style>
            .card-container {
                background-color: #ffffff;
                border-radius: 12px;
                box-shadow: 0 6px 12px 0 rgba(0,0,0,0.15);
                padding: 30px;
                margin-bottom: 20px;
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
            }
            .card-title {
                font-size: 26px;
                font-weight: bold;
                color: #333333;
                margin-bottom: 10px;
            }
            .card-text {
                font-size: 17px;
                color: #666666;
                margin-bottom: 15px;
            }
            .card-image {
                width: 180px;
                height: 180px;
                border-radius: 50%;
                object-fit: cover;
                margin-bottom: 20px;
                border: 3px solid #4CAF50;
            }
            </style>
                       
            """, unsafe_allow_html=True)
            
            st.markdown(f'<div class="card-container"> {response}', unsafe_allow_html=True)
   